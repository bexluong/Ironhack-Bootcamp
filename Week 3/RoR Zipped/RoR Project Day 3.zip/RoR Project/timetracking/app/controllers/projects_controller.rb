class ProjectsController < ApplicationController

  def index
    @projects = Project.order(created_at: :desc).limit(10)
    @lastproject = Project.last
  end

  def show
    @my_project = Project.find_by(id: params[:project_id])
    unless @my_project #unless my project is true aka it exists
      render 'no_projects_found' #old fashioned vendor, b/c by default it will show, however if you put render it'd find another page
#this pushes view we want
    end
  end

  def new
    @my_project = Project.new
  end

  def create
@my_project = Project.new(
:name => params[:project][:name],
:description => params[:project][:description])#helpers create them see it in the view source the name
@my_project.save #where you save the info into the database

redirect_to "/projects/#{@my_project.id}"
  end

end
