class TimeEntry < ActiveRecord::Base
belongs_to :project

end
